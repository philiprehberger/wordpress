<?php get_header(); ?>

<div id="main-content" class="clearfix">
	<div id="left-area">
		<?php get_template_part('loop','single'); ?>
	</div> <!-- end #left-area -->

	<?php get_sidebar(); ?>

<?php get_footer(); ?>