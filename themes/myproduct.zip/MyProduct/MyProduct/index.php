<?php get_header(); ?>

<div id="content-left">
	
	<?php get_template_part('includes/entry'); ?>		
	
</div> <!-- end #content-left -->
			
<?php get_sidebar(); ?>

<?php get_footer(); ?>