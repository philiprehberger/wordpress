<div id="left-div">
   <?php if (get_option('puretype_format') == 'on') { ?>
		<?php get_template_part('includes/blogstyle'); ?>
    <?php } else { get_template_part('includes/default'); } ?>
</div>