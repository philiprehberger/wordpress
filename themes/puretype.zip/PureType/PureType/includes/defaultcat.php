<span class="current-category">
<?php single_cat_title(esc_html__('Currently Browsing: ','PureType'), 'display'); ?>
</span>
<?php get_template_part('includes/defaultindex'); ?>