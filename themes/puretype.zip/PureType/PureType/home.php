<?php get_header(); ?>

<div id="container">
<?php get_template_part('includes/post_format'); ?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
</body>
</html>