<?php get_header(); ?>

<?php get_template_part('includes/entry','index'); ?>
	
<?php get_footer(); ?>