<?php if (get_option('ebusiness_blog_style') == 'on') { ?>
<?php get_template_part('includes/bloghome'); ?>
<?php } else { get_template_part('includes/default'); } ?>