	<?php get_template_part('includes/scripts'); ?>
	<?php wp_footer(); ?>
</body>
</html>