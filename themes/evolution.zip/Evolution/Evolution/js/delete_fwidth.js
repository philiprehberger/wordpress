jQuery(document).ready(function() {
	jQuery('label #et_fullwidthpage').parent().parent().removeClass('et_pt_portfolio');
});