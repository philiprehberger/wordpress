<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
	<article class="entry post clearfix">
		<?php if (get_option('evolution_integration_single_top') <> '' && get_option('evolution_integrate_singletop_enable') == 'on') echo(get_option('evolution_integration_single_top')); ?>
		
		<h1 class="main_title"><?php the_title(); ?></h1>
		
		<?php get_template_part('includes/postinfo','single'); ?>
		
		<?php
			$thumb = '';
			$width = apply_filters( 'evolution_single_image_width', 203 );
			$height = apply_filters( 'evolution_single_image_height', 203 );
			$classtext = '';
			$titletext = get_the_title();
			$thumbnail = get_thumbnail($width,$height,$classtext,$titletext,$titletext,false,'Single');
			$thumb = $thumbnail["thumb"];
		?>
		<?php if ( '' <> $thumb && 'on' == get_option( 'evolution_thumbnails' ) ) { ?>
			<div class="single-thumbnail">
				<?php print_thumbnail($thumb, $thumbnail["use_timthumb"], $titletext, $width, $height, $classtext); ?>
				<span class="post-overlay"></span>
			</div> 	<!-- end .post-thumbnail -->
		<?php } ?>
	
		<?php the_content(); ?>
		<?php wp_link_pages(array('before' => '<p><strong>'.esc_attr__('Pages','Evolution').':</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
		<?php edit_post_link(esc_attr__('Edit this page','Evolution')); ?>
	</article> <!-- end .entry -->

	<?php if (get_option('evolution_integration_single_bottom') <> '' && get_option('evolution_integrate_singlebottom_enable') == 'on') echo(get_option('evolution_integration_single_bottom')); ?>
	
	<?php 
		if ( get_option('evolution_468_enable') == 'on' ){
			if ( get_option('evolution_468_adsense') <> '' ) echo( get_option('evolution_468_adsense') );
			else { ?>
			   <a href="<?php echo esc_url(get_option('evolution_468_url')); ?>"><img src="<?php echo esc_url(get_option('evolution_468_image')); ?>" alt="468 ad" class="foursixeight" /></a>
	<?php 	}    
		}
	?>
	
	<?php 
		if ( 'on' == get_option('evolution_show_postcomments') ) comments_template('', true);
	?>
<?php endwhile; // end of the loop. ?>