<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/lavalamp.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/easing.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/cluetip/jquery.cluetip.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/slider.js"></script>