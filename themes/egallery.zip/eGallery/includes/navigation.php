<p class="pagination">
	<?php next_posts_link(esc_html__('&laquo; Older Entries','eGallery')) ?>
	<?php previous_posts_link(esc_html__('Next Entries &raquo;', 'eGallery')) ?>
</p>