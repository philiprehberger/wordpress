<?php get_header(); ?>
	
	<div id="main-content">
		<?php get_template_part('includes/entry'); ?>
	</div> <!-- end #main-content -->

	<?php get_sidebar(); ?>
		
<?php get_footer(); ?>