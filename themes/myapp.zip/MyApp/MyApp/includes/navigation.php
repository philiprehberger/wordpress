<div class="pagination">
	<div class="alignleft"><?php previous_posts_link(esc_html__('Newer Posts', 'MyAppTheme')) ?></div>
	<div class="alignright"><?php next_posts_link(esc_html__('Older Posts','MyAppTheme')) ?></div>
</div>