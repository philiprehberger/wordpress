<?php
	$arr = array();
	$i=1;
	
	$width = 36;
	$height = 37;
			
	$featured_cat = get_option('myapptheme_feat_cat');
	$featured_num = (int) get_option('myapptheme_featured_num');
	
	if (get_option('myapptheme_use_pages') == 'false') query_posts("showposts=$featured_num&cat=".get_catId($featured_cat));
	else { 
		global $pages_number;
		
		if (get_option('myapptheme_feat_pages') <> '') $featured_num = count(get_option('myapptheme_feat_pages'));
		else $featured_num = $pages_number;
		
		query_posts(array
						('post_type' => 'page',
						'orderby' => 'menu_order',
						'order' => 'ASC',
						'post__in' => (array) get_option('myapptheme_feat_pages'),
						'showposts' => $featured_num
					));
	};
	
	while (have_posts()) : the_post();
			
		$arr[$i]["title"] = truncate_title(350,false);
		$arr[$i]["fulltitle"] = truncate_title(350,false);
		
		global $more;   
		$more = 0; 
		$arr[$i]["content"] = get_the_content('');
		$arr[$i]["content"] = apply_filters('the_content', $arr[$i]["content"]);
		
		$arr[$i]["tabtitle"] = get_post_meta($post->ID, 'Tab', $single = true);
		$arr[$i]["permalink"] = get_permalink();
		
		$arr[$i]["thumb"] = '';
		$arr[$i]["thumb"] = get_post_meta($post->ID, 'Icon', $single = true);

		$i++;
	endwhile; wp_reset_query();	?>

	
<div id="side-tabs">
	<ul>
		<?php for ($i = 1; $i <= $featured_num; $i++) { ?>
			<?php if ($arr[$i]["tabtitle"] == '') $arr[$i]["tabtitle"] = 'Tab Custom field'; ?>
			<li class="clearfix"><a href="#" <?php if ($i == 1) echo(' class="activeTab"'); ?>><?php if($arr[$i]["thumb"] <> '') echo('<img src="'.esc_url( $arr[$i]["thumb"] ).'" alt="" width="36" height="37" />'); ?><span><?php echo( esc_html( $arr[$i]["tabtitle"] ) ); ?></span></a></li>
		<?php }; ?>
	</ul> 	
</div> <!-- end #side-tabs -->


<div id="main-area">
	<?php for ($i = 1; $i <= $featured_num; $i++) { ?>
		<div class="tab-content<?php if ($i == 1) echo(' active'); ?>">
			<h2 class="title"><?php echo(esc_html($arr[$i]["title"])); ?></h2>
			<?php echo($arr[$i]["content"]); ?>
			<a href="<?php echo esc_url($arr[$i]["permalink"]); ?>" class="readmore"><span><?php esc_html_e('Read More','MyAppTheme'); ?></span></a>
		</div> <!-- end .tab-content -->
	<?php }; ?>
</div> <!-- end #main-area -->