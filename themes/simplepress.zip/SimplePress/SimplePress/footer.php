<br class="clear" />
<div id="footer">
	<?php esc_html_e('Designed by ','SimplePress'); ?> <a href="http://themesddl.com" title="Elegant Themes">Elegant Themes</a> | <?php esc_html_e('Powered by ','SimplePress'); ?> <a href="http://www.wordpress.org">Wordpress</a>
</div>
<?php wp_footer(); ?>	
<?php get_template_part('includes/scripts'); ?>

</body>
</html>
