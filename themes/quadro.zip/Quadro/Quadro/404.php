<?php get_header(); ?>

<div id="container">
	<div id="container2">

		<div id="left-div">

			<div class="post-wrapper">
			<?php esc_html_e('Sorry, the page your requested could not be found, or no longer exists.','Quadro');?> 
			</div>
		   
		</div>
	</div>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
</body>
</html>
