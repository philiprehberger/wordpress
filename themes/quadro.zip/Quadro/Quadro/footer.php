		<div id="footer">
			<?php esc_html_e('Designed by ','Quadro'); ?> <a href="http://themesddl.com" title="Elegant Themes">Elegant Themes</a> | <?php esc_html_e('Powered by ','Quadro'); ?> <a href="http://www.wordpress.org">Wordpress</a>
		</div> <!-- end #footer -->
	</div> <!-- end #wrapper2 -->
</div> <!-- end #bg -->

<?php get_template_part('includes/scripts'); ?>
<?php wp_footer(); ?>