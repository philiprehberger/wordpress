	<div id="footer">
		<?php esc_html_e('Designed by ','ArtSee'); ?> <a href="http://themesddl.com" title="Elegant Themes">Elegant Themes</a> | <?php esc_html_e('Powered by ','ArtSee'); ?> <a href="http://www.wordpress.org">Wordpress</a>
	</div> <!-- end #footer -->
	<div style="clear: both;"></div>

</div> <!-- end #wrapper2 -->
<?php get_template_part('includes/scripts'); ?>
<?php wp_footer(); ?>