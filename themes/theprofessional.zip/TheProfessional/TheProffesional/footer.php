		<div id="footer" class="clearfix">
			<p id="copyright"><?php esc_html_e('Designed by ','Professional'); ?> <a href="http://themesddl.com" title="Elegant Themes">Elegant Themes</a> | <?php esc_html_e('Powered by ','Professional'); ?> <a href="http://www.wordpress.org">Wordpress</a></p>
		</div> <!-- end #footer -->
		
	</div> <!-- end #container -->	

	<?php get_template_part('includes/scripts'); ?>
	<?php wp_footer(); ?>	
</body>
</html>