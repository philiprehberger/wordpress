<p class="pagination">
    <?php next_posts_link(esc_html__('&laquo; Previous Entries','Glow')) ?>
   <?php previous_posts_link(esc_html__('Next Entries &raquo;','Glow')) ?>
</p>