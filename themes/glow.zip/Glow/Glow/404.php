<?php get_header(); ?>
<div id="main-area-wrap">
	<div id="wrapper">
		<div id="main">
			<div class="post">
				<h2><?php esc_html_e('Sorry, the page your requested could not be found, or no longer exists.','Glow'); ?></h2>
			</div> <!-- end post -->
		</div> <!-- end main -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>