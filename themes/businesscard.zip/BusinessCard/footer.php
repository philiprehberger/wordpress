
<?php wp_footer(); ?>
<?php get_template_part('includes/scripts'); ?>
</body>
</html>