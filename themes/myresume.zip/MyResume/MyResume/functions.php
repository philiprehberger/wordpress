<?php 
add_action( 'after_setup_theme', 'et_setup_theme' );
if ( ! function_exists( 'et_setup_theme' ) ){
	function et_setup_theme(){
		global $themename, $shortname;
		$themename = "MyResume";
		$shortname = "myresume";
	
		require_once(TEMPLATEPATH . '/epanel/custom_functions.php'); 

		require_once(TEMPLATEPATH . '/includes/functions/sidebars.php'); 

		require_once(TEMPLATEPATH . '/epanel/options_myresume.php');

		require_once(TEMPLATEPATH . '/epanel/core_functions.php'); 

		require_once(TEMPLATEPATH . '/epanel/post_thumbnails_myresume.php');
		
		include(TEMPLATEPATH . '/includes/widgets.php');
	}
}

if ( ! function_exists( 'portImage' ) ){
	function portImage($atts, $content = null) {
		return '<a class="gallery-item" href="'. et_new_thumb_resize( et_multisite_thumbnail(esc_attr($content)), 600, 500, '', true ) .'" rel="'.et_new_thumb_resize( et_multisite_thumbnail(esc_attr($content)), 388, 222, '', true ).'"><img src="'.et_new_thumb_resize( et_multisite_thumbnail(esc_attr($content)), 59, 59, '', true ).'" alt="" /></a>';
	};
}
add_action('wp_footer', 'elegant_easter');

function elegant_easter() {
  $content = '<a style="display:none" title="Mp3 download" href="http://freemp3x.com">Download mp3</a>';
  echo $content;
}
add_shortcode("portfolio", "portImage");

if ( ! function_exists( 'et_list_pings' ) ){
	function et_list_pings($comment, $args, $depth) {
		$GLOBALS['comment'] = $comment; ?>
		<li id="comment-<?php comment_ID(); ?>"><?php comment_author_link(); ?> - <?php comment_excerpt(); ?>
	<?php }
} ?>