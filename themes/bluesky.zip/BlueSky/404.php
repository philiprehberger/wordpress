<?php get_header(); ?>

<div id="container">
<div id="container2">
    <div id="left-div">
        <div style="font-size: 20px;">
            <h1><?php esc_html_e('Not Found','Bluesky');?></h1>
            <p><?php esc_html_e('The page you requested could not be found. Try refining your search, or use the navigation above to locate the post.','Bluesky');?></p>
        </div>
    </div>
</div>
<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
</body>
</html>