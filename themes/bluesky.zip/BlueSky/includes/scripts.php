<?php global $shortname; ?>

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/idtabs.js"></script>