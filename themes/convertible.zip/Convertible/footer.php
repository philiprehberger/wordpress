			</div> <!-- end #content -->
		</div> <!-- end #container -->

		<footer id="main_footer" class="clearfix">
			<p id="copyright"><?php printf( __('Designed by %s | Powered by %s', 'Convertible'), '<a href="http://themesddl.com" title="Premium WordPress Themes">Elegant WordPress Themes</a>', '<a href="http://www.wordpress.org">WordPress</a>' ); ?></p>
			<?php do_action('et_convertible_footer'); ?>
		</footer>

	</div> <!-- end #wrapper -->

	<?php wp_footer(); ?>

</body>
</html>