<div style="position: relative;">
    <div class="ad_468"> <a href="<?php echo esc_url(get_option('ephoto_468_url')); ?>"><img src="<?php echo esc_attr(get_option('ephoto_468_image')); ?>" alt="banner ad" style="float: left; margin-left: 80px; border: none;" /></a> </div>
</div>