<div style="clear: both;"></div>
</div>
</div>
</div>

<div id="footer">
<div class="footer-inside"><?php esc_html_e('Powered by ','ePhoto'); ?> <a href="http://www.wordpress.com">WordPress</a> | <?php esc_html_e('Designed by ','ePhoto'); ?> <a href="http://themesddl.com">Elegant Themes</a>
</div>

</div>

<?php get_template_part('includes/scripts'); ?>
<?php wp_footer(); ?>