<h3 id="slogan"><span><?php the_title(); ?></span></h3>
<?php global $more;   
	  $more = 0; 
	  the_content(""); ?>