<?php get_header(); ?>

	<div id="content-area" class="clearfix">
		<?php get_template_part('includes/entry'); ?>
	</div> <!-- #content-area -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>