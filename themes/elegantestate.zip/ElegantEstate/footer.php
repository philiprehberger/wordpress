			</div> <!-- end #content-->
		</div> <!-- end #content-top-->
		<div id="content-bottom">	</div>
		<p id="copyright"><?php esc_html_e('Designed by ','ElegantEstate'); ?> <a href="http://themesddl.com" title="Elegant Themes">Elegant Themes</a> | <?php esc_html_e('Powered by ','ElegantEstate'); ?> <a href="http://www.wordpress.org">Wordpress</a></p>

		</div> 	<!-- end #container -->
	</div> 	<!-- end #wrapper -->

	<?php get_template_part('includes/scripts'); ?>

	<?php wp_footer(); ?>
</body>
</html>