<?php get_header(); ?>

	<?php get_template_part('includes/featured'); ?>
	<div id="content-top">
		<div id="content" class="clearfix">
			<div id="main-area">
				<?php get_template_part('includes/entry'); ?>
			</div> <!-- end #main-area-->

			<?php get_sidebar(); ?>

		<?php get_footer(); ?>