<div class="adwrap">
<a href="<?php echo esc_url(get_option('lightsource_banner_twofifty_url')) ?>"><img src="<?php echo esc_url(get_option('lightsource_banner_twofifty_image')) ?>" style="border: none;" alt="advertisement" /></a>
</div>