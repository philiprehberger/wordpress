<div class="entry clearfix">
	<?php get_template_part('includes/entry','home'); ?>
</div> <!-- end .entry -->