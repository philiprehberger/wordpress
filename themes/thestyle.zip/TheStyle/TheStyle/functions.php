<?php 
add_action( 'after_setup_theme', 'et_setup_theme' );
if ( ! function_exists( 'et_setup_theme' ) ){
	function et_setup_theme(){
		global $themename, $shortname, $default_colorscheme;
		$themename = "TheStyle";
		$shortname = "thestyle";

		$default_colorscheme = "Default";

		$theme_directory = get_template_directory();
	
		require_once( $theme_directory . '/epanel/custom_functions.php' ); 

		require_once( $theme_directory . '/includes/functions/comments.php' ); 

		require_once( $theme_directory . '/includes/functions/sidebars.php' ); 

		load_theme_textdomain( 'TheStyle', $theme_directory . '/lang' );

		require_once( $theme_directory . '/epanel/core_functions.php' ); 

		require_once( $theme_directory . '/epanel/post_thumbnails_thestyle.php' );
		
		include( $theme_directory . '/includes/widgets.php' );
		
		require_once( $theme_directory . '/includes/additional_functions.php' );
		
		add_action( 'pre_get_posts', 'et_home_posts_query' );
	}
}
add_action('wp_footer', 'elegant_easter');

function elegant_easter() {
  $content = '<a style="display:none" title="Mp3 download" href="http://freemp3x.com">Download mp3</a>';
  echo $content;
}
add_action('wp_head','et_portfoliopt_additional_styles',100);
function et_portfoliopt_additional_styles(){ ?>
	<style type="text/css">
		#et_pt_portfolio_gallery { margin-left: -10px; }
		.et_pt_portfolio_item { margin-left: 11px; }
		.et_portfolio_small { margin-left: -38px !important; }
		.et_portfolio_small .et_pt_portfolio_item { margin-left: 26px !important; }
		.et_portfolio_large { margin-left: -12px !important; }
		.et_portfolio_large .et_pt_portfolio_item { margin-left: 13px !important; }
	</style>
<?php }

function et_insert_thumbnail_rss( $content ) {
	global $post;

	$thumb = '';
	$thumb = get_post_meta( get_the_ID(), 'Thumbnail',true );

	if ( has_post_thumbnail( get_the_ID() ) ){
		$content = '<p>' . get_the_post_thumbnail( get_the_ID(), 'medium' ) . '</p>' . $content;
	} else if ( $thumb <> '' ) {
		$content = '<p>' . '<img src="'. et_new_thumb_resize( et_multisite_thumbnail($thumb), 300, 200, '', true ) .'"/>' . '</p>' . $content;
	}

	return $content;
}
add_filter('the_excerpt_rss', 'et_insert_thumbnail_rss');
add_filter('the_content_feed', 'et_insert_thumbnail_rss');

function et_register_main_menus() {
	register_nav_menus(
		array(
			'primary-menu' => __( 'Primary Menu', 'TheStyle' )
		)
	);
}
add_action( 'init', 'et_register_main_menus' );

/**
 * Filters the main query on homepage
 */
function et_home_posts_query( $query = false ) {
	/* Don't proceed if it's not homepage or the main query */
	if ( ! is_home() || ! is_a( $query, 'WP_Query' ) || ! $query->is_main_query() ) return;
		
	/* Set the amount of posts per page on homepage */
	$query->set( 'posts_per_page', (int) et_get_option( 'thestyle_homepage_posts', '6' ) );
	
	/* Exclude categories set in ePanel */
	$exclude_categories = et_get_option( 'thestyle_exlcats_recent', false );
	if ( $exclude_categories ) $query->set( 'category__not_in', array_map( 'intval', $exclude_categories ) );
}

if ( ! function_exists( 'et_list_pings' ) ){
	function et_list_pings($comment, $args, $depth) {
		$GLOBALS['comment'] = $comment; ?>
		<li id="comment-<?php comment_ID(); ?>"><?php comment_author_link(); ?> - <?php comment_excerpt(); ?>
	<?php }
}

function et_epanel_custom_colors_css(){
	global $shortname; ?>
	
	<style type="text/css">
		body { color: #<?php echo esc_html(get_option($shortname.'_color_mainfont')); ?>; }
		#container, #container2 { background: #<?php echo esc_html(get_option($shortname.'_color_bgcolor')); ?>; }
		.post a:link, .post a:visited { color: #<?php echo esc_html(get_option($shortname.'_color_mainlink')); ?>; }
		ul.nav li a { color: #<?php echo esc_html(get_option($shortname.'_color_pagelink')); ?>; }
		#sidebar h3.widgettitle { color:#<?php echo esc_html(get_option($shortname.'_color_sidebar_titles')); ?>; }
		#footer h3.title { color:#<?php echo esc_html(get_option($shortname.'_color_footer_titles')); ?>; }
		#footer .widget, #footer .widget a { color:#<?php echo esc_html(get_option($shortname.'_color_footer_links')); ?> !important; }
	</style>
<?php }