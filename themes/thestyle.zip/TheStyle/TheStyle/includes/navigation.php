<?php next_posts_link('<span id="right-arrow"></span>', 0); ?>
<?php previous_posts_link('<span id="left-arrow"></span>', 0); ?>