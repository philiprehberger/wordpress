<div class="entry">
<!--If no results are found-->
	<h1><?php esc_html_e('No Results Found','TheStyle'); ?></h1>
	<p><?php esc_html_e('The page you requested could not be found. Try refining your search, or use the navigation above to locate the post.','TheStyle'); ?></p>
</div>	
<!--End if no results are found-->