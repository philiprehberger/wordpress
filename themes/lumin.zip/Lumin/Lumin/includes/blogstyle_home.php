<div class="post index">
	<?php get_template_part('includes/category_usual'); ?>
	<div class="clear"></div>
</div> <!-- end .post -->