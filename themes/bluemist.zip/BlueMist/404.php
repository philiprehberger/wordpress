<?php get_header(); ?>

<div id="wrapper">
	<div id="content-wrapper">
		<div id="content">
			<div style="font-size: 20px;"><?php esc_html_e('Sorry, the page your requested could not be found, or no longer exists.','BlueMist');?> </div>
		</div>
	</div>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
</body>
</html>