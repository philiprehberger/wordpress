<div class="pagination">
	<div class="alignleft"><?php next_posts_link(esc_html__('&laquo; Older Entries','BlueMist')) ?></div>
	<div class="alignright"><?php previous_posts_link(esc_html__('Next Entries &raquo;', 'BlueMist')) ?></div>
</div>