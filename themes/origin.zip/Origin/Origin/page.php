<?php get_header(); ?>

<?php get_template_part('loop', 'page'); ?>

<?php get_template_part('includes/copyright', 'page'); ?>

<?php get_footer(); ?>