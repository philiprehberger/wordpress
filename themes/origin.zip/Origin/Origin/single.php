<?php get_header(); ?>

<?php get_template_part('loop', 'single'); ?>

<?php get_template_part('includes/copyright', 'single'); ?>
	
<?php get_footer(); ?>