		</div> <!-- end #content-->
		
		<div id="footer" class="clearfix">
			<p id="copyright"><?php esc_html_e('Powered by ','PersonalPress'); ?> <a href="http://www.wordpress.com">WordPress</a> | <?php esc_html_e('Designed by ','PersonalPress'); ?> <a href="http://themesddl.com">Elegant Themes</a></p>
		</div>
	</div> <!-- end #page-wrap-->
	
	<?php get_template_part('includes/scripts'); ?>
	<?php wp_footer(); ?>
</body>
</html>