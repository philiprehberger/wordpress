<div id="footer"><?php esc_html_e('Powered by ','StudioBlue'); ?> <a href="http://www.wordpress.com">WordPress</a> | <?php esc_html_e('Designed by ','StudioBlue'); ?> <a href="http://themesddl.com">Elegant Themes</a></div>
<div style="clear: both;"></div>
</div>

<?php get_template_part('includes/scripts'); ?>
<?php wp_footer(); ?>