					<?php get_sidebar( 'footer' ); ?>
				</div> <!-- #content -->
				<div id="footer-bottom">
					<p id="copyright"><?php printf( __( 'Designed by %1$s | Powered by %2$s', 'StyleShop' ), '<a href="http://themesddl.com" title="Premium WordPress Themes">Elegant Themes</a>', '<a href="http://www.wordpress.org">WordPress</a>' ); ?></p>
				</div> <!-- #footer-bottom -->
			</div> <!-- #container -->
		</div> <!-- #main-page-wrapper -->
	</div> <!-- #page-wrap -->

	<?php wp_footer(); ?>
</body>
</html>