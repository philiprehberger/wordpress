<div class="entry">
	<div class="entry-top">
		<div class="entry-content">
			<!--If no results are found-->
				<h1><?php esc_html_e('No Results Found','AskIt'); ?></h1>
				<p><?php esc_html_e('The page you requested could not be found. Try refining your search, or use the navigation above to locate the post.','AskIt'); ?></p>
			<!--End if no results are found-->
		</div> <!-- end .entry-content -->
	</div> <!-- end .entry-top -->
</div> <!-- end .entry -->