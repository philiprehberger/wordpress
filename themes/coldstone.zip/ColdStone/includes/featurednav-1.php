<ul class="tabNavigation">
    <li><a href="#tab1">1.</a></li>
</ul>