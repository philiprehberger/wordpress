<div style="clear: both;"></div>
<a href="<?php echo esc_url(get_option('coldstone_banner_468_url')); ?>"><img src="<?php echo esc_attr(get_option('coldstone_banner_468')); ?>" alt="banner ad" style="float: left; margin-left: 40px; margin-top: 20px; margin-bottom: 20px; border: none;" /></a>
<div style="clear: both;"></div>