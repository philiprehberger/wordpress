<ul class="tabNavigation">
    <li><a href="#tab1">1.</a></li>
    <li><a href="#tab2">2.</a></li>
</ul>