<?php get_header(); ?>

<div class="single_wrap">
    <div class="single_post">
        <h2><?php esc_html_e('Sorry, this page does not exist.','ColdStone'); ?></h2>
        <?php esc_html_e('The page you have requested was not found or has moved. Feel free to use the search bar above to locate your desired post.','ColdStone'); ?> </div>
    <!-- /single_post -->
    <?php get_sidebar(); ?>
</div>
<div class="footer" style="height:15px;margin-bottom:0;"></div>
<?php get_footer(); ?>