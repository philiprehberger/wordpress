		</section> <!-- end #recent-posts -->

		<div id="widgets">
			<?php dynamic_sidebar('Sidebar'); ?>
		</div> <!-- end #widgets -->
	</div> <!-- end #content -->

	<?php wp_footer(); ?>
</body>
</html>