jQuery(document).ready(function() {
	jQuery('label #et_fullwidthpage').parent().parent().remove();
});