<?php get_header(); ?>

<?php get_template_part('includes/breadcrumbs'); ?>

<div id="main-area">
	<div id="main-content" class="clearfix">
		<div id="left-column">
			<?php get_template_part('includes/entry'); ?>
		</div> <!-- #left-column -->

		<?php get_sidebar(); ?>

<?php get_footer(); ?>