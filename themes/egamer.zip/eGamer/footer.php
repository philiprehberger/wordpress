<div style="clear: both;"></div>
</div>
</div>
<div id="footer">
    <div style="width: 915px; padding-left: 25px; margin-left: auto; margin-right: auto; display: block;"><?php esc_html_e('Powered by ','eGamer'); ?> <a href="http://www.wordpress.com">WordPress</a> | <?php esc_html_e('Designed by ','eGamer'); ?> <a href="http://themesddl.com">Elegant Themes</a> </div>
</div>

<?php get_template_part('includes/scripts'); ?>
<?php wp_footer(); ?>