﻿<!--Begin 468x60 Ad-->
<div style="position: relative; width: 940px; margin: -18px auto 0px auto;"><a href="<?php echo esc_url(get_option('egamer_468_url')); ?>" title="Advertisement"><img src="<?php echo esc_attr(get_option('egamer_468_image')); ?>" alt="pages bg right" style="margin-top: 24px; border: none; position: absolute; left: 472px;" /></a></div>
<!--End 468x60 Ad-->