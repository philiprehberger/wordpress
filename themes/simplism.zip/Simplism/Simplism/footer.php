	<div id="footer">
		<?php esc_html_e('Designed by ','Simplism'); ?> <a href="http://themesddl.com" title="Elegant Themes">Elegant Themes</a> | <?php esc_html_e('Powered by ','Simplism'); ?> <a href="http://www.wordpress.org">Wordpress</a>
	</div> <!-- end #footer -->
</div> <!-- end #wrapper2 -->

<?php get_template_part('includes/scripts'); ?>
<?php wp_footer(); ?>