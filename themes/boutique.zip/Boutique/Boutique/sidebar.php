<div id="sidebar">
	<?php dynamic_sidebar('Sidebar'); ?>
</div> <!-- end #sidebar -->