<div class="pagination">
	<div class="alignleft"><?php next_posts_link(esc_html__('&laquo; Older Entries','OnTheGo')) ?></div>
	<div class="alignright"><?php previous_posts_link(esc_html__('Next Entries &raquo;', 'OnTheGo')) ?></div>
</div>