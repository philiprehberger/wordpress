<div class="post index">
	<?php get_template_part('includes/entry','home'); ?>
	<div class="clear"></div>
</div> <!-- end .post -->