<div id="footer"><?php esc_html_e('Powered by ','WhosWho'); ?> <a href="http://www.wordpress.com">WordPress</a> | <?php esc_html_e('Designed by ','WhosWho'); ?> <a href="http://themesddl.com">Elegant Themes</a></div>
<div style="clear: both;"></div>
</div>

<?php get_template_part('includes/scripts'); ?>
<?php wp_footer(); ?>