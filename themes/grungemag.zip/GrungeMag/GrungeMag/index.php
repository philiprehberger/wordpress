<?php get_header(); ?>	

<?php get_template_part('includes/defaultindex'); ?>