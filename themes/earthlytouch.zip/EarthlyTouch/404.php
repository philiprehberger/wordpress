<?php get_header(); ?>

<div id="container">
	<div id="left-div">
		<div id="left-inside">
			<div style="font-size: 20px;"><?php esc_html_e('Sorry, the page your requested could not be found, or no longer exists.','EarthlyTouch');?> </div>
		</div>
	</div>
	<!--Begin Sidebar-->
	<?php get_sidebar(); ?>
	<!--End Sidebar-->

</div>

<!--Begin Footer-->
<?php get_footer(); ?>
<!--End Footer-->
</body>
</html>