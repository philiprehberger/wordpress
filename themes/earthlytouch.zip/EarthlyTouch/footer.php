	<div id="footer">
		<?php esc_html_e('Designed by ','EarthlyTouch'); ?> <a href="http://themesddl.com" title="Elegant Themes">Elegant Themes</a> | <?php esc_html_e('Powered by ','EarthlyTouch'); ?> <a href="http://www.wordpress.org">Wordpress</a>
	</div> <!-- end #footer -->

</div>

<?php get_template_part('includes/scripts'); ?>
<?php wp_footer(); ?>