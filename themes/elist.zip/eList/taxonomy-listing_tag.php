<?php get_header(); ?>

<?php get_template_part('includes/recent_listings','index'); ?>

<?php get_footer(); ?>