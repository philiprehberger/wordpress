﻿<?php if ( !empty($post->post_password) && $_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) : ?>

<p>
    <?php esc_html_e('Enter your password to view comments.','InterPhase'); ?>
</p>
<?php return; endif; ?>
<h2 id="comments" style="margin-top: 15px;">
    <?php comments_number(esc_html__('No Comments','InterPhase'), esc_html__('1 Comment','InterPhase'), esc_html__('% Comments','InterPhase')); ?>
    <?php if ( comments_open() ) : ?>
    <a href="#postcomment" title="<?php esc_attr_e('Leave a comment','InterPhase'); ?>">&raquo;</a>
    <?php endif; ?>
</h2>
<?php if ($comments) : ?>
<ol class="commentlist">
    <?php foreach ($comments as $comment) : ?>
    <li>
        <div>
            <div class="comment-author vcard"> <?php echo get_avatar( $comment, $size = '60' );  ?> <cite class="fn">
                <?php comment_author_link() ?>
                </cite> <span class="says"><?php esc_html_e('says:','InterPhase'); ?></span> </div>
            <div class="comment-meta commentmetadata"> <a href="#comment-<?php comment_ID() ?>" title="">
                <?php comment_date('F jS, Y') ?>
                </a></div>
            <?php comment_text() ?>
        </div>
    </li>
    <?php endforeach; ?>
</ol>
<div style="clear: both;"></div>
<?php else : // If there are no comments yet ?>
<p>
    <?php esc_html_e('No comments yet.','InterPhase'); ?>
</p>
<?php endif; ?>
<p>
    <?php post_comments_feed_link(esc_html__('<abbr title="Really Simple Syndication">RSS</abbr> feed for comments on this post.','InterPhase')); ?>
    <?php if ( pings_open() ) : ?>
    <a href="<?php trackback_url() ?>" rel="trackback">
    <?php esc_html_e('TrackBack <abbr title="Universal Resource Locator">URL</abbr>','InterPhase'); ?>
    </a>
    <?php endif; ?>
</p>
<?php if ( comments_open() ) : ?>
<h2 id="postcomment">
    <?php esc_html_e('Leave a comment','InterPhase'); ?>
</h2>
<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
<p><?php printf(esc_html__('You must be <a href="%s">logged in</a> to post a comment.','InterPhase')), get_option('siteurl')."/wp-login.php?redirect_to=".urlencode(get_permalink()));?></p>
<?php else : ?>
<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
    <?php if ( $user_ID ) : ?>
    <p><?php printf(esc_html__('Logged in as %s.','InterPhase'), '<a href="'.get_option('siteurl').'/wp-admin/profile.php">'.$user_identity.'</a>'); ?> <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="<?php esc_attr_e('Log out of this account','InterPhase'); ?>">
        <?php esc_html_e('Log out &raquo;','InterPhase'); ?>
        </a></p>
    <?php else : ?>
    <p>
        <input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="22" tabindex="1" />
        <label for="author"><small>
            <?php esc_html_e('Name','InterPhase'); ?>
            <?php if ($req) esc_html_e('(required)','InterPhase'); ?>
            </small></label>
    </p>
    <p>
        <input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="22" tabindex="2" />
        <label for="email"><small>
            <?php esc_html_e('Mail (will not be published)','InterPhase') ?>
            <?php if ($req) esc_html_e('(required)','InterPhase'); ?>
            </small></label>
    </p>
    <p>
        <input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="22" tabindex="3" />
        <label for="url"><small>
            <?php esc_html_e('Website','InterPhase'); ?>
            </small></label>
    </p>
    <?php endif; ?>
    <!--<p><small><strong>XHTML:</strong> <?php printf(esc_html__('You can use these tags: %s','InterPhase'), allowed_tags()); ?></small></p>-->
    <p>
        <textarea name="comment" id="comment" cols="100%" rows="10" tabindex="4"></textarea>
    </p>
    <p>
        <input name="submit" type="submit" id="submit" tabindex="5" value="<?php echo attribute_escape(esc_attr__('Submit Comment','InterPhase')); ?>" />
        <input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
    </p>
    <?php do_action('comment_form', $post->ID); ?>
</form>
<?php endif; // If registration required and not logged in ?>
<?php else : // Comments are closed ?>
<p>
    <?php esc_html_e('Sorry, the comment form is closed at this time.','InterPhase'); ?>
</p>
<?php endif; ?>
