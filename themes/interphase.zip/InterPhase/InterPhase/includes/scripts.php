<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/slider.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/cluetip/jquery.cluetip.js" type="text/javascript"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$('#categories .cat-item a').cluetip({splitTitle: '|'});
	});
</script>