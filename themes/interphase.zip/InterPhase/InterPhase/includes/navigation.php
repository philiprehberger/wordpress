<p class="pagination">
	<?php next_posts_link(esc_html__('&laquo; Older Entries','InterPhase')) ?>
	<?php previous_posts_link(esc_html__('Next Entries &raquo;', 'InterPhase')) ?>
</p>